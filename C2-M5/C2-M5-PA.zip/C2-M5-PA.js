// Given variables
const dishData = [
    {
        name: "Italian pasta",
        price: 9.55
    },
    {
        name: "Rice with veggies",
        price: 8.65
    },
    {
        name: "Chicken with potatoes",
        price: 15.55
    },
    {
        name: "Vegetarian Pizza",
        price: 6.45
    },
]
const tax = 1.20;

// Implement getPrices()
function getPrices(taxBoolean) {
    for (let i = 0; i < dishData.length; i++) {
        var finalPrice;
        if (taxBoolean) {
            finalPrice = dishData[i].price * tax
        } else if (!taxBoolean) {
            finalPrice = dishData[i]
        } else {
            console.log("You need to pass a boolean to the getPrices call!")
            return;
        }

        console.log("Dish: " + dishData[i].name + "\nPrice: " + finalPrice)
    }
}

// Implement getDiscount()
function getDiscount(taxBoolean, guests) {
    getPrices(taxBoolean)
    if (typeof guests === "number" && guests < 30 && guests > 0) {
        var discount = 0
        if (guests < 5) {
            discount = 5
        } else if (guests >= 5) {
            discount = 10
        } else {
            console.log("The second argument must be a number between 0 and 30")
        }
    }
    console.log("Discount is: $" + discount)
}

// Call getDiscount()
getDiscount(true, 11)